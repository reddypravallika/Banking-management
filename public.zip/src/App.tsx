import React from 'react';
import logo from './logo.svg';
import './App.css';
import {BrowserRouter,Routes,Route} from "react-router-dom"
import Login from './components/Login';
import Registration from './components/Registration';
import Dashboard from './components/Dashboard';
function App() {
  return (
   <>
   
   <BrowserRouter>
   <Routes>
     <Route path="/login" element={<Login />} />
     <Route path="/registration" element={<Registration />} />
     <Route path="/dashboard" element={<Dashboard />} />

   </Routes>
   </BrowserRouter>
   
   </>);
}

export default App;
