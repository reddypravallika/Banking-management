import React, { useState } from "react";

enum LoanType {
  Personal = "Personal",
  Housing = "Housing",
  Educational = "Educational",
}

interface LoanFormState {
  loanType: LoanType;
  loanAmount: number;
  loanApplyDate: string;
  interestRate: number;
  duration: number;
  // Additional fields for Education Loan
  courseFee: number;
  course: string;
  fatherName: string;
  fatherOccupation: string;
  annualIncomeEdu: number;
  // Additional fields for Personal/Home Loan
  annualIncomePH: number;
  companyName: string;
  designation: string;
  totalExperience: number;
  expWithCurrentCompany: number;
}

const Dashboard: React.FC = () => {
  const [formData, setFormData] = useState<LoanFormState>({
    loanType: LoanType.Personal,
    loanAmount: 0,
    loanApplyDate: "",
    interestRate: 0,
    duration: 5,
    courseFee: 0,
    course: "",
    fatherName: "",
    fatherOccupation: "",
    annualIncomeEdu: 0,
    annualIncomePH: 0,
    companyName: "",
    designation: "",
    totalExperience: 0,
    expWithCurrentCompany: 0,
  });

  const [errors, setErrors] = useState<Partial<LoanFormState>>({});

//   const validateForm = () => {
//     const newErrors: Partial<LoanFormState> = {};

//     // Validation logic for Account holder name (assuming it's common for all loan types)
//     if (!formData.fatherName.match(/^[A-Za-z ]+$/)) {
//       newErrors.fatherName = "Account holder name should contain only alphabets and space.";
//     }

//     // Validation logic for other common fields
//     // if (!formData.loanAmount || formData.loanAmount <= 0) {
//     //   newErrors.loanAmount = "Loan amount should be greater than zero.";
//     // }

//     // Add more validation logic for specific loan types (Educational, Personal/Home)
//     // if (formData.loanType === LoanType.Educational) {
//     //   if (!formData.courseFee || formData.courseFee <= 0) {
//     //     newErrors.courseFee = "Course fee should be greater than zero.";
//     //   }
//     //   // Add more validation for educational loan fields
//     // } else if (formData.loanType === LoanType.Personal || formData.loanType === LoanType.Housing) {
//     //   if (!formData.annualIncomePH || formData.annualIncomePH <= 0) {
//     //     newErrors.annualIncomePH = "Annual income should be greater than zero.";
//     //   }
//       // Add more validation for personal/home loan fields
//     }

    // Other validation rules (e.g., loan apply date, duration, etc.)

    // setErrors(newErrors);

    // return Object.values(newErrors).every((error) => !error);
//   };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

   console.log(FormData,"formData")
  };

  const handleChange = (
    e:
      | React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>
      | React.ChangeEvent<HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  return (
    <div className="max-w-screen-xl mx-auto bg-white p-6 rounded-md shadow-md">
      <h1 className="text-2xl font-semibold mb-4 text-center">Loan Application</h1>
      <form onSubmit={handleSubmit}>
        {/* Loan Type */}
        <div className="grid grid-cols-6 gap-2">
        <div className="mb-4">
          <label className="block text-gray-700">Loan Type</label>
          <select
            className="w-full border rounded-md py-2 px-3"
            
          >
            <option selected disabled>Select Loan Type</option>
            {Object.values(LoanType).map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* Loan Amount */}
        <div className="mb-4">
          <label className="block text-gray-700">Loan Amount</label>
          <input
            type="number"
            className="w-full border rounded-md py-2 px-3"
            onChange={handleChange}
            
          />
          {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Apply Date Of Loan</label>
          <input
            type="date"
            className="w-full border rounded-md py-2 px-3"
            onChange={handleChange}
            
          />
          {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Rate Of  Interest</label>
          <input
            type="number"
            className="w-full border rounded-md py-2 px-3"
            onChange={handleChange}
            
          />
          {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Duration Of  Loan</label>
          <input
            type="number"
            className="w-full border rounded-md py-2 px-3"
            onChange={handleChange}
            
          />
          {/* {errors.loanAmount && <p className="text-red-500">{errors.loanAmount}</p>} */}
        </div>

        <div className="mt-6 text-center">
          <button
            type="submit"
            className="bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600"
          >
            Apply for Loan
          </button>
        </div>
        </div>
      </form>
    </div>
  );
};

export default Dashboard;
